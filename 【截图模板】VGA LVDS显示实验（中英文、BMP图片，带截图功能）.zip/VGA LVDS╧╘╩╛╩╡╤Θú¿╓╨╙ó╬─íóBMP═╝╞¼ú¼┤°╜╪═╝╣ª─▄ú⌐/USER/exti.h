#ifndef __EXTI_H
#define	__EXTI_H

#include "stm32f10x.h"
#include "stm32f10x_exti.h"
#include "misc.h"
void Key_EXTI_PB1_Config(void);

#endif
