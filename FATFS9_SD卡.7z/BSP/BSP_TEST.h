  
#include "stm32f10x.h"
#include "sdio_sdcard.h"
#include "usart1.h"	
#include "ff.h"

void test_config(void);


void SD_test(void);

